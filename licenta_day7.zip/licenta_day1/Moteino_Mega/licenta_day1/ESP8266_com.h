#ifndef ESP8266_COM
#define ESP8266_COM

#define SERIAL1_BAUD      115200 // Serial baud rate

#define WiFi_SID    "GoAway"
#define WiFi_PASS   "123321ABCcba"

#define    SMTP_PORT    "465"
#define    SMTP_ADDRESS "smtp.gmail.com"
#define    EMAIL_USER   "YXZhZGFuZWlsYXJpc2FAZ21haWwuY29t" 
#define    EMAIL_PASS   "U3R5a3VsMDMyOA=="
#define    EMAIL_FROM   "avadaneilarisa@gmail.com"
#define    EMAIL_DEST   "avadaneilarisa@gmail.com"

void  ResetWiFi();

bool  InitWiFi();
bool  InitSMTP();

bool  SendEmail(char* pin);


#endif
